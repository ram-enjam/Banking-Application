﻿//$(document).ready(function () {
//$("#btnGET").on("click", function () { });
//$("#btnPOST").on("click", function () { });
//$("#btnPUT").on("click", function () { });
//});

IKL = {};

IKL = {
    jQBasic: {
        onLoad: function () {
            try {
                $("#btnGET").on("click", function () { IKL.jQBasic.getRequest(false); });
                $("#btnPOST").on("click", function () { IKL.jQBasic.postRequest(true); });
                $("#btnPUT").on("click", function () { IKL.jQBasic.putRequest(true); });
            } catch (e) {
                console.error(e.message || e.description);
            }
        },

        getRequest: function (async) {
            try {
                $.ajax({
                    url: "https://jsonplaceholder.typicode.com/users",
                    async: async,
                    method: "GET",
                    dataType: "json",
                    success: function (data, status, jqXhr) {
                        console.log("Parth: I am inside");
                        IKL.jQBasic.createUserTable(data);
                    },
                    error: function (jqXhr, textStatus, errorMessage) {
                        console.error(errorMessage);
                    }
                });
                console.log("Parth: I am outside");
            } catch (e) {
                console.error(e.message || e.description);
            }
        },

        postRequest: function (async) {
            try {
                var title = $("#txtTitle").val();
                var id = $("#txtID").val();
                var body = $("#txtBody").val();

                var postBody = {
                    "title": title,
                    "id": id,
                    "body": body
                };

                $.ajax({
                    url: "https://jsonplaceholder.typicode.com/posts",
                    async: async,
                    method: "POST",
                    dataType: "json",
                    body: JSON.stringify(postBody),
                    headers: {
                        "Content-type": "application/json; charset=UTF-8"
                    },
                    success: function (data, status, jqXhr) {
                        IKL.jQBasic.provideFeedback();
                    },
                    error: function (jqXhr, textStatus, errorMessage) {
                        console.error(errorMessage);
                    }
                });
            }
            catch (e) {
                console.error(e.message || e.description);
            }
        },

        putRequest: function (async) {
            var title = $("#txtTitle").val();
            var id = $("#txtID").val();
            var body = $("#txtBody").val();

            var postBody = {
                "title": title,
                "id": id,
                "body": body,
                "userId": id
            };

            $.ajax({
                url: "https://jsonplaceholder.typicode.com/posts/1",
                async: async,
                method: "PUT",
                dataType: "json",
                body: JSON.stringify(postBody),
                headers: {
                    "Content-type": "application/json; charset=UTF-8"
                },
                success: function (data, status, jqXhr) {
                    IKL.jQBasic.provideFeedback();
                },
                error: function (jqXhr, textStatus, errorMessage) {
                    console.error(errorMessage);
                }
            });
        },

        /**
         * 
         * @param {any} data
         */
        createUserTable: function (data) {
            try {
                $("#divUser").show();
                
                $("#divFeedback").hide();
                $("#divUser").empty();

                var divHeader = "";
                divHeader += "<div class='row mt-4'></div>";
                divHeader += "<div class='row' id='divHeader'>";
                divHeader += "<div class='col-lg-3'></div>";
                divHeader += "<div class='col-lg-3 text-center userHeader'>Name</div>";
                divHeader += "<div class='col-lg-3 text-center userHeader'>Email</div>";
                divHeader += "<div class='col-lg-3'></div>";
                divHeader += "</div>";

                var divBody = "";
                $.each(data, function (index, item) {
                    divBody += "<div class='row' id='divBody" + index + "'>";
                    divBody += "<div class='col-lg-3'></div>";
                    divBody += "<div class='col-lg-3 text-center userBody'>" + item.name + "</div>";
                    divBody += "<div class='col-lg-3 text-center userBody'>" + item.email + "</div>";
                    divBody += "<div class='col-lg-3'></div>";
                    divBody += "</div>";
                });

                divHeader += divBody;

                $(divHeader).appendTo("#divUser");
            } catch (e) {
                console.error(e.message || e.description);
            }
        },

        provideFeedback: function () {
            try {
                $("#divFeedback").show();
                $("#divFeedback").empty();
                $("#divUser").hide();

                var divFeedback = "";
                divFeedback += "<div class='row mt-4'></div>";
                divFeedback += "<div class='row'>";
                divFeedback += "<div class='col-lg-3'></div>";
                divFeedback += "<div class='col-lg-6 text-center alert alert-success' role='alert'>Successfully Completed</div>";
                divFeedback += "<div class='col-lg-3'></div>";
                divFeedback += "</div>";

                $(divFeedback).appendTo("#divFeedback").fadeOut(4000);
            }
            catch (e) {
                console.error(e.message || e.description);
            }
        }
    }
}