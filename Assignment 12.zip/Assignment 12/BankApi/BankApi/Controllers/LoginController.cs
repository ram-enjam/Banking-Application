﻿using BankApi.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Windows.Forms;

namespace BankApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class LoginController : ApiController
    {

        //sql connection
        SqlConnection connect = new SqlConnection(ConfigurationManager.ConnectionStrings["registration"].ConnectionString);

        SqlCommand sqlCmd = new SqlCommand();
        //http get method for implementing http verbs

        //method to show all the data in table.
        [HttpPost]
        [ActionName("GetLoginDetails")]
        public bool GetLoginDatails(Login login)
        {
            string functionName = "Get Login Details";
            try
            {
                sqlCmd.CommandType = CommandType.Text;
                //command for validate the data fron Registration Table.
                sqlCmd.CommandText = "Select Email_id,Password from Registration where Email_id='"+login.Email_id+"' and Password='"+login.Password+"'";
                
                //connecting the sql sever
                sqlCmd.Connection = connect;
                //sql connection opened
                connect.Open();
                sqlCmd.ExecuteNonQuery();
                //sql connection closed
                connect.Close();

                SqlDataAdapter datdadp = new SqlDataAdapter(sqlCmd);
                DataTable datatable = new DataTable();
                datdadp.Fill(datatable);
                if (datatable.Rows.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                    //MessageBox.Show("Invalid username or password!!");
                }
            }
            catch (Exception e)
            {
                throw new Exception(functionName + ">>>" + e.Message);
            }
        }

        [HttpPost]
        [ActionName("Showuserdata")]

        public List<ShowUserData> showUserdata(Login login)
        {
            string functionName = "Get user Details";
            try
            {
                //created a list of model class.
                List<ShowUserData> userdata = new List<ShowUserData>();

                sqlCmd.CommandType = CommandType.Text;
                //command for showing the data fron Registration Table.
                sqlCmd.CommandText = "Select First_Name,Last_Name,Mobile_No,Email_id from Registration where Email_id='" + login.Email_id+ "'";
                //connecting the sql sever
                sqlCmd.Connection = connect;
                //sql connection opened
                connect.Open();
                using (SqlDataReader sdr = sqlCmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        userdata.Add(new ShowUserData()
                        {
                            //to read the data from book table.
                            First_Name = Convert.ToString(sdr["First_Name"]),
                            Last_Name = Convert.ToString(sdr["Last_Name"]),
                            Mobile_No = Convert.ToDecimal(sdr["Mobile_No"]),
                            Email_id = Convert.ToString(sdr["Email_id"])
                           
                        });
                    }
                }
                //sql connection closed
                connect.Close();
                //returned values
                return userdata;
            }
            catch (Exception e)
            {
                throw new Exception(functionName + ">>>" + e.Message);
            }
        }
    }
}
