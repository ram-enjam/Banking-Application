﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BankApi.Models;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.Http.Cors;

namespace BankApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class RegisterController : ApiController
    {
        
        //sql connection
        SqlConnection connect = new SqlConnection(ConfigurationManager.ConnectionStrings["registration"].ConnectionString);

        SqlCommand sqlCmd = new SqlCommand();
        //http get method for implementing http verbs

        //method to show all the data in table.
        [HttpGet]
        [ActionName("GetDetails")]
        public List<Registration> GetCustomerDatails()
        {
            string functionName = "Get Details";
            try
            {
                //created a list to show all the data from database.
                List<Registration> registerlist = new List<Registration>();

                sqlCmd.CommandType = CommandType.Text;
                //command for showing the data fron Registration Table.
                sqlCmd.CommandText = "Select * from Registration";
                //connecting the sql sever
                sqlCmd.Connection = connect;
                //sql connection opened
                connect.Open();
                using (SqlDataReader sdr = sqlCmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        registerlist.Add(new Registration()
                        {
                            //to read the data from book table.
                            First_Name = Convert.ToString(sdr["First_Name"]),
                            Last_Name = Convert.ToString(sdr["Last_Name"]),
                            Mobile_No = Convert.ToDecimal(sdr["Mobile_No"]),
                            Email_id = Convert.ToString(sdr["Email_id"]),
                            Password = Convert.ToString(sdr["Password"])
                        });
                    }
                }
                //sql connection closed
                connect.Close();
                //returned values
                return registerlist;
            }
            catch (Exception e)
            {
                throw new Exception(functionName + ">>>" + e.Message);
            }
        }
             //method to add book details in table
        [HttpPost]
        [ActionName("AddDetails")]
        public void AddCustomerDetails(Registration register)
        {
            string functionName = "Add Details";
            try
            {
                 sqlCmd.CommandType = CommandType.Text;
                //inserting values into table using sql command.
                 sqlCmd.CommandText = "INSERT INTO Registration (First_Name,Last_Name,Mobile_No,Email_id,Password) Values (@First_Name,@Last_Name,@Mobile_No,@Email_id,@Password)";
                 //connecting the sql sever
                 sqlCmd.Connection = connect;
                 connect.Open();
                 
                //adding the values into book table.
                 sqlCmd.Parameters.AddWithValue("@First_Name", register.First_Name);
                 sqlCmd.Parameters.AddWithValue("@Last_Name", register.Last_Name);
                 sqlCmd.Parameters.AddWithValue("@Mobile_No", register.Mobile_No);
                 sqlCmd.Parameters.AddWithValue("@Email_id", register.Email_id);
                 sqlCmd.Parameters.AddWithValue("@Password", register.Password);

               
                //created row to insert new values in table
                  int rowInserted = sqlCmd.ExecuteNonQuery();  
                //sql connection closed.
                  connect.Close(); 
 
             }
             catch (Exception ex)
             {
                throw new Exception( functionName +">>>" + ex.Message);
             }
        }
    }
}
