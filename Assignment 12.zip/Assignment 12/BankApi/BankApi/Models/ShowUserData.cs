﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BankApi.Models
{
    public class ShowUserData
    {
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public decimal Mobile_No { get; set; }
        public string Email_id { get; set; }
    }
}