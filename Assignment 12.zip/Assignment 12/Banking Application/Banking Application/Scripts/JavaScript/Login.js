﻿var BankingSystem = {};

BankingSystem = {
    Login: function (async) {
        var functionName="Login"
        try {
            var email_id = $("#email").val();
            var password = $("#pswd").val();

            var ReadBody = {
                "Email_id": email_id,
                "Password": password
            };
            $.ajax({
                url: "http://localhost:50278/api/Login/GetLoginDetails",
                async: async,
                method: "POST",
                dataType: "json",
                data: JSON.stringify(ReadBody),
                headers: {

                    "Content-type": "application/json; charset=UTF-8"
                },
                success: function (data, status, jqXhr) {
                    if (data == true) {
                        alert("Login Successfull");
                        window.location.assign("UserPage.html");
                    }
                    else{
                        alert("Invalid username or password !!");
                    }
                },
                error: function (jqXhr, textStatus, errorMessage) {
                   
                    console.error(errorMessage); 
                }
            });
        }
        catch(e)
        {
            alert(functionName + ">>>" + e.message);
        }
    }
}
$(document).ready(function () {
    var functionName = "Main Page Load"
    try {
        //Calling function on button login.
        $("#loginbtn").on("click", function () {
            BankingSystem.Login(true);
        });
    }
    catch (e) {
        alert(functionName+">>>"+e.message);
    }
});