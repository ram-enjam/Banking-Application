﻿var BankingSystem = {};

BankingSystem = {
    userDetails: function (async) {
        var functionName = "User Details Function"
        try {
            var email_id = $("#emailid").val();
           
            var ReaduserBody = {
                "Email_id": email_id
            };
            $.ajax({
                url: "http://localhost:50278/api/Login/Showuserdata",
                async: async,
                method: "POST",
                dataType: "json",
                data: JSON.stringify(ReaduserBody),
                headers: {

                    "Content-type": "application/json; charset=UTF-8"
                },
                success: function (data, status, jqXhr) {
                    BankingSystem.ShowUserData(data);
                },
                error: function (jqXhr, textStatus, errorMessage) {
                    console.error(errorMessage);
                }
            });

        } catch (e) {
            alert(functionName + ">>>" + e.message)
        }
    },
    ShowUserData: function (data) {
        var functionName="Show user data"
        try {
            // $("#hidedata").show();
            
            $.each(data, function (First_Name, Last_Name, Mobile_No, Email_id) {
                $("#firstName").val() = First_Name;
                $("#lastName").val() = Last_Name;
                $("#mobileNo").val() = Mobile_No;
                $("#useremailid").val() = Email_id;
            });
        } catch (e) {
            alert(functionName+">>>"+e.message)

        }
    }
}
$(document).ready(function () {
    var functionName = "Main Page Load"
    try {
        //Calling function on button search.
        $("#searchuser").on("click", function () {
            BankingSystem.userDetails(true);
        });
    }
    catch (e) {
        alert(functionName+">>>"+e.message);
    }
});