﻿var BankingSystem = {};

BankingSystem = {
        Registration: function(async) {
            var functionName="Registration"
            try {
                var first_name=$("#firstNametxt").val();
                var last_name=$("#lastnametxt").val();
                var phone_no=$("#phoneNumbertxt").val();
                var email_id=$("#emailidtxt").val();
                var password=$("#pwdtxt").val();
                var confirm_pwd=$("#confirmpwdtxt").val();

                //validation.
                if (first_name == "") {
                    alert("Please enter your First Name");
                    $("#firstNametxt").focus();
                }
                else if (last_name == "") {
                    alert("Please enter your Last Name");
                    $("#lastnametxt").focus();
                }
                else if (phone_no == "") {
                    alert("Please enter your Phone Number");
                    $("#phoneNumbertxt").focus();

                }
                else if (email_id == "") {
                    alert("Please enter The Valid Email Id");
                    $("#emailidtxt").focus();
                }
                else if (password == "") {
                    alert("Please enter The Valid Password");
                    $("#pwdtxt").focus();
                }
                else if (confirm_pwd == "") {
                    alert("Please enter The Valid Password");
                    $("#confirmpwdtxt").focus();
                }
                    //if validation is correct it will get into function.
                else {
                    var addBody = {
                        "First_Name": first_name,
                        "Last_Name": last_name,
                        "Mobile_No": phone_no, "Email_id": email_id, "Password": password,
                    };
                    //
                    if (password == confirm_pwd) {
                        $.ajax({

                            url: "http://localhost:50278/api/Register/AddDetails",
                            async: async,
                            method: "POST",
                            dataType: "json",

                            data: JSON.stringify(addBody),

                            headers: {

                                "Content-type": "application/json; charset=UTF-8"
                            },

                            success: function (data, status, jqXhr) {
                                 $("input:text").val('');
                                 alert("Registered Successfully");
                                 window.location.assign("LoginPage.html");
                               
                            },
                            error: function (jqXhr, textStatus, errorMessage) {
                                console.error(errorMessage);
                            }
                        });
                    }
                    else {
                        alert("Password is not matching !!")
                    }
                }
            }
            catch (e) {
                alert(functionName+">>>"+e.message)
            }
        }
}
$(document).ready(function () {
    var functionName="Main Page Load"
    try {
        //Calling function on button deposite.
        $("#registerbtn").on("click", function () {
           
            BankingSystem.Registration(true);
        });
    }
    catch(e){
        alert(functionName+">>>>"+e.message);
    }
});